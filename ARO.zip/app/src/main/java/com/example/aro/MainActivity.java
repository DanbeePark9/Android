package com.example.aro;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    TextView tv;
    ImageView iv;
    Button bt1, bt2, bt3;
    int my[]={R.drawable.apple, R.drawable.banana, R.drawable.melon};
    int cnt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt1 = this.findViewById(R.id.button1);
        iv = this.findViewById(R.id.myImg);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv.setImageResource(my[cnt]);
                cnt++;
                if(cnt==3) {cnt=0;
                    Toast.makeText(MainActivity.this, "3번째 그림", Toast.LENGTH_SHORT).show();}
            }
        });
    }//onCreate end
}//class end