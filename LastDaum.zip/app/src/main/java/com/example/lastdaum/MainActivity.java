package com.example.lastdaum;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    ArrayList<Fruit> al = new ArrayList<Fruit>();
    Fruit m1;
    KakaoAdapter dap ;
    ListView lv;

   public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv=findViewById(R.id.listView1);

         al.add(new Fruit(R.drawable.melon,"메론",false, "2019.03.02"));
         al.add(new Fruit(R.drawable.remon,"레몬",true, "2020.02.21"));
         al.add(new Fruit(R.drawable.jadoo,"자두",true, "2019.01.31"));
         al.add(new Fruit(R.drawable.singer4,"소냐",false, "2019.03.08"));
            m1=new Fruit();
            m1.img=R.drawable.cherry;
            m1.name="체리";
            m1.taste=true;
            m1.date="2020.03.01";
         al.add(m1);
        al.add(new Fruit(R.drawable.banana,"바나나",false, "2019.03.08"));


         //KakaoAdapter클래스 전역변수 dap선언후
         dap=new KakaoAdapter(this, R.layout.kakao, al);
         //어텁터를 ListView연결  set
         lv.setAdapter(dap);

         lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                 Fruit ff = (Fruit)dap.getItem(position);
                 String msg=ff.name +" 과일선택하셨군요";
                 int imgNum=ff.img; //그림id

                 Toast tt = Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG);
                 //tt.show();


                View dlg=View.inflate(MainActivity.this, R.layout.display, null);
                //ImageView poster=dlg.findViewById(R.id.ivPoster);  dlg안쓰면 프로그램 다운 조심
                ImageView poster=dlg.findViewById(R.id.ivPoster);
                poster.setImageResource(imgNum);

                 AlertDialog.Builder ab = new AlertDialog.Builder(adapterView.getContext());
                 ab.setTitle("상세정보");
                 ab.setIcon(R.drawable.x);
                 ab.setMessage(msg);
                 ab.setView(dlg);
                 ab.setNegativeButton("close", null);
                 ab.show();
             }
         });

    }//end
}//MainActivity class END


class KakaoAdapter extends BaseAdapter {
    Context ct;
    int layout;
    LayoutInflater inf;
    ArrayList<Fruit> al;

    public KakaoAdapter(Context ct) {
        this.ct = ct;
    }//end

    public KakaoAdapter(Context ct, int layout,  ArrayList<Fruit> al) {
        this.ct = ct;
        this.layout = layout;
        this.inf = (LayoutInflater)ct.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.al = al;
    }//생성자end


    //==========Adapter의 추상메소드 4개
    @Override
    public int getCount() {
        return al.size();
    }//end

    @Override
    public Object getItem(int position) {
        return al.get(position);
    }//end

    @Override
    public long getItemId(int position) {
        return position;
    }//end

    @Override
    public View getView(int position, View cv, ViewGroup parent) {
        if(cv==null) cv=inf.inflate(layout, null);

        ImageView iv=cv.findViewById(R.id.imageView1);
        TextView tName=cv.findViewById(R.id.tvName);
        TextView tTast=cv.findViewById(R.id.tvFrom);
        TextView tDate=cv.findViewById(R.id.tvDate);

        Fruit f = al.get(position);
        iv.setImageResource(f.img);
        tName.setText(f.name);
        tTast.setText(f.taste ? "달콤달콤" : "새콤새콤");
        tDate.setText(f.date);
        return cv;
    }//end
}//KakaoAdpter클래스 end

