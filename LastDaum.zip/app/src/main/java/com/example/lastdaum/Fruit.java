package com.example.lastdaum;

public class Fruit {
    int img;  //과일그림
    String name; //과일이름
    String  from ;  //과일원산지
    boolean taste; //과일맛
    String date; //과일입고날짜

    public  Fruit( ) {  }

    public Fruit(int img, String name, boolean taste,String date){
        this.img=img;
        this.name=name;
        this.taste=taste;
        this.date=date;
    }//end

}//Fruit 과일class END
