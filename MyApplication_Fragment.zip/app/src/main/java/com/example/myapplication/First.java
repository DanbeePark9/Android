package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.aro.R;

public class First extends  Fragment {
    ImageView iv;
    Button bt1, bt2, bt3;
    int my[]= { R.drawable.bbb, R.drawable.gguri, R.drawable.bt  };
    int cnt = 0;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstance){
        View v = inflater.inflate(R.layout.activity_first, container, false);

        iv = v.findViewById(R.id.myImg); //필수항목

        bt1=v.findViewById(R.id.button1);
        bt1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                iv.setImageResource(my[cnt]);
                cnt++;
                if (cnt==3) cnt=0;
            }
        });

        bt2=v.findViewById(R.id.button2);
        bt2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(getActivity(), Two.class);
                it.putExtra("LG", "gold key");
                startActivity(it);
            }
        });

        bt3=v.findViewById(R.id.button3);
        bt3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast tt = Toast.makeText(getActivity(),"화면 closing...", Toast.LENGTH_SHORT);
                tt.show();
                ((MainActivity)getActivity()).onBackPressed();
            }
        });

        return v;
    }//end


}//Firstclass END