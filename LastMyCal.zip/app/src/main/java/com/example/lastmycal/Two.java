package com.example.lastmycal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Two extends AppCompatActivity {
    TextView textView;
    EditText editText;
    String rule=""; //사칙연산기호
    float value1; //값1
    float value2; //값2
    boolean check=false; //기호 연속입력방지 (기호 입력시 true로)


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);

        textView=findViewById(R.id.view);
        editText=findViewById(R.id.edit);
        editText.setInputType(0); //타자기가 안뜸
    }//end


    public void num(View vw){
        String str = editText.getText().toString();

        switch (vw.getId()){
            case R.id.num0:
                editText.append("0");
                textView.append("0");
                break;
            case R.id.num1:
                editText.append("1");
                break;
            case R.id.num2:
                editText.append("2");
                break;
            case R.id.num3:
                editText.append("3");
                break;
            case R.id.num4:
                editText.append("4");
                break;
            case R.id.num5:
                editText.append("5");
                break;
            case R.id.num6:
                editText.append("6");
                break;
            case R.id.num7:
                editText.append("7");
                break;
            case R.id.num8:
                editText.append("8");
                break;
            case R.id.num9:
                editText.append("9");
                break;
            case R.id.delete:
                editText.setText(str.substring(0, str.length()-1));
                break;
            case R.id.allclear:
                editText.setText(str.substring(0, 0));
                textView.setText(str.substring(0, 0));
                break;
        }
    }//num end

    public void symbol(View v){ //기호 입력시 실행
        String str = editText.getText().toString();
        String tvStr = textView.getText().toString();

        switch (v.getId()){
            case R.id.plus:
                rule="+";
                break;
        }
        if(tvStr.endsWith("+")){
            textView.setText(tvStr);
        } else {
            textView.setText(tvStr+rule);
        }
    }//end

    public void equal(View v){ //등호의 경우

    } // equal end

    private void initialize(){ //초기화 함수

    }//initialize end

    public void calculate(){ //계산함수

    }//end

    public String setNum(float num){
        return null;
    }//end
}//class END