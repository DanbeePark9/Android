package com.example.aro;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class two extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);

        TextView tv = this.findViewById(R.id.twoTv); //twoTv라는 아이디를 가지고 있는 텍스트 뷰를 찾는다.
        Intent intent = this.getIntent();

        //3
        //tv.setText("pinksky"); //텍스트뷰에 텍스트를 삽입한다.
        tv.setText(intent.getCharSequenceExtra("LA")); // 여러개를 넘길때는 배열로 넘긴다.
    }
}