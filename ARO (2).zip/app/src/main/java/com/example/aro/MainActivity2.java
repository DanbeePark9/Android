package com.example.aro;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends Activity {
    TextView tv;
    ImageView iv;
    Button bt1, bt2, bt3;
    int my[] = {R.drawable.apple, R.drawable.banana, R.drawable.melon};
    int cnt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv = this.findViewById(R.id.myImg); //필수항목

        bt1 = this.findViewById(R.id.button1);
        bt2 = this.findViewById(R.id.button2);
        bt3 = this.findViewById(R.id.button3);
        iv = this.findViewById(R.id.myImg);


        // 이렇게 기술하는것의 단점 = 버튼갯수만큼 온클릭리스너를 기술해야함
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv.setImageResource(my[cnt]);
                cnt++;
                if (cnt == 3) {
                    cnt = 0;
                    Toast.makeText(
                            getApplication(),
                            "3번째 그림",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //two.java 문서로 이동
                //Intent it = new Intent(현재클래스, 이동할클래스);
                //Intent it = new Intent(MainActivity.this, two.class);
                Intent it = new Intent(getApplication(), two.class);
                it.putExtra("LG", "cake");
                startActivity(it);
            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String info = "어플을 종료합니다.";
                //구글 안드로이드앱에서는 클래스 이름들이 대부분 디저트 이름이다
                //확인버튼 없는 간단한 알림창
                //Toast tt = Toast.makeText(MainActivity.this, info, Toast.LENGTH_LONG); tt.show();
                Toast.makeText(getApplication(), info, Toast.LENGTH_LONG).show();
                finish(); //현재 Activity 창 닫기
            }
        });
    }//onCreate end

}//class end