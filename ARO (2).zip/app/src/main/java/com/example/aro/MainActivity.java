package com.example.aro;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    TextView tv;
    ImageView iv;
    Button bt1, bt2, bt3;
    int my[]={R.drawable.apple, R.drawable.banana, R.drawable.melon};
    int cnt = 0;

    Button myDelete;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //myDelete = new Button("삭제버튼");

        iv = this.findViewById(R.id.myImg); //필수항목
    }//end

    public void check(View vw){
        int id = vw.getId(); //뷰 영역에서 id 값을 리턴해줌

        if(id==R.id.button1){
            iv.setImageResource(my[cnt]);
            cnt++;
            if(cnt==3) cnt=0;
        } else if(id==R.id.button2) {
            //1 (현재문서, 이동할문서)
            Intent it = new Intent(this, two.class);
            //2 two로 이동할거야
            it.putExtra("LA","Don't settle");
            //3 two로 이동하기 시작해
            startActivity(it);
        } else if(id==R.id.button3) {
            Toast.makeText(this, "closing the application", Toast.LENGTH_SHORT).show();
            this.finish();
        }//if end

    }//end

}//class end

