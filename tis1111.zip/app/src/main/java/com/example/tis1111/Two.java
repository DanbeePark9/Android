package com.example.tis1111;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Two extends Activity {
    public void onCreate( Bundle savedInstance){
        super.onCreate(savedInstance);
        setContentView(R.layout.activity_two);

        TextView tv = findViewById(R.id.twoTv);
        Intent it = this.getIntent();
        //tv.setText("blueberry");
        tv.setText(it.getCharSequenceExtra("LG"));
    }
}//class END

/*
public class Two extends Fragment {
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstance){
        View v = inflater.inflate(R.layout.activity_two, container, false);

        TextView tv = v.findViewById(R.id.twoTv);
        Bundle bun = getArguments();
        String msg=bun.getString("LG");
        //tv.setText("blueberry");
        tv.setText(msg);
        return  v;
    }
}//class END

*/