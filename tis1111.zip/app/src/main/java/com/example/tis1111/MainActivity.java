package com.example.tis1111;

import android.os.Bundle;
import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;


public class MainActivity extends FragmentActivity  {
    ViewPager vp1;
    ViewPagerAdapter vpAdapter;
    Fragment fragment[] = new Fragment[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vp1 = (ViewPager) findViewById(R.id.vp1);

        fragment[0] = new First();
        fragment[1] = new Cal();
        fragment[2] = new Three();

        vpAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        vp1.setAdapter(vpAdapter);
    }//end

    public void move(View v) {
        switch(v.getId()){
            case R.id.tv1: vp1.setCurrentItem(0); break;
            case R.id.tv2: vp1.setCurrentItem(1); break;
            case R.id.tv3: vp1.setCurrentItem(2); break;
        }
    }//end

    private class ViewPagerAdapter extends FragmentStatePagerAdapter {
        public ViewPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }//end

        @Override
        public Fragment getItem(int position) {
            return fragment[position];
        }//end

        @Override
        public int getCount() {
            return fragment.length;
        }
    }//class END

}//MainActivity class END