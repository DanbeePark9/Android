package com.example.tis1111;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class Cal extends  Fragment {

    EditText editText;

    TextView textView;
    String rule="";  //사칙연산기호
    float value1;   //값1
    float value2;   //값2
    boolean check=false;    // 기호 연속입력방지 (기호 입력시 true, 숫자 입력시 false)


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstance){
        View v = inflater.inflate(R.layout.activity_cal, container, false);

        textView=(TextView)v.findViewById(R.id.view);
        editText=(EditText)v.findViewById(R.id.edit);
        editText.setInputType(0);
        return v;
    }//end

    public void num(View v) {
        String strtmp = editText.getText().toString();
        if (rule.equals("=") || rule.equals("error")) {     // 전에 입력한 기호가 등호였거나 에러인경우 초기화
            initialize();
        }
        if (check) {                                        // 직전에 기호 입력되었던 경우 + 다음에 숫자를 누르는 경우
            editText.setText("");                           // 입력부분 초기화
            check = false;                                  // 숫자 입력
        }
        if (strtmp.startsWith("0") && !(strtmp.startsWith("0."))) { // 0으로 시작되는 경우(소숫점 0.으로 시작되는것 제외) 0 지움
            editText.setText("");
        }
        switch (v.getId()) {        //입력값
            case R.id.allclear:     //전부 지우기
                initialize();
                break;
            case R.id.delete:       // 입력부분 하나씩 지우기
                if (!(strtmp.equals("")))   // 입력부분이 빈칸이 아닌 경우
                    editText.setText(strtmp.substring(0, strtmp.length() - 1)); // 뒤에서부터 하나씩 지움
                if((strtmp.length()==2) && strtmp.startsWith("-"))              // 입력부분이 음수인 한자리 수인 경우 한번에 지움
                    editText.setText("");
                break;
            //숫자 입력
            case R.id.num0:
                editText.append("0");
                break;
            case R.id.num1:
                editText.append("1");
                break;
            case R.id.num2:
                editText.append("2");
                break;
            case R.id.num3:
                editText.append("3");
                break;
            case R.id.num4:
                editText.append("4");
                break;
            case R.id.num5:
                editText.append("5");
                break;
            case R.id.num6:
                editText.append("6");
                break;
            case R.id.num7:
                editText.append("7");
                break;
            case R.id.num8:
                editText.append("8");
                break;
            case R.id.num9:
                editText.append("9");
                break;
            case R.id.point:        // 소수점 입력
                if (editText.getText().toString().equals("")) { // 입력부분이 빈칸인 상태에서 소수점 입력할 경우
                    editText.append("0");                       // 0 자동 입력
                } else if (editText.getText().toString().contains(".")) {   // 입력부분에 점이 있는 경우
                    break;                                                    // 입력하지 않음
                }
                editText.append(".");   // 소수점 추가
                break;
            case R.id.whole:            // 음수, 양수 변환
                if(!editText.getText().toString().equals("")) { // 입력 부분이 빈칸이 아닌 경우
                    float numtmp = Float.parseFloat(strtmp);     // 입력 문자열 float형으로 변환
                    numtmp *= (-1);                               // 양수, 음수 전환
                    editText.setText(setNum(numtmp));            // 입력 부분에 적용
                }
                break;
        }
    }//end

    public void symbol(View v) {                                // 기호 입력 시
        String strtmp = editText.getText().toString();          // 입력 부분 문자열로 전환
        if (rule.equals("=") || rule.equals("error")) {       // 전에 입력한 기호가 등호거나 에러인 경우
            initialize();
        }
        if (!strtmp.equals("")) {                               // 입력 부분 빈칸이 아닐 경우
            if (!check) {                                       // 직전에 누른 버튼이 기호가 아닐 경우(숫자일 경우)
                float numtmp = Float.parseFloat(strtmp);        // 입력 부분 문자열 숫자로 전환
                if (value1 == 0) {                              // 계산 중인 식이 없다면
                    value1 = numtmp;
                    editText.setText(setNum(value1));
                } else {                                        // 계산 중인 식이 있다면
                    value2 = numtmp;
                    calculate();                                 // 이어서 계산
                }
                textView.append(setNum(numtmp));                // 입력한 숫자 뷰에 출력
            }
            switch (v.getId()) {                                // 입력 값
                // 기호 입력
                case R.id.divide:
                    if ((Float.parseFloat(strtmp) == 0) && rule.equals("÷")) {  // 입력 부분의 숫자가 0 이고, 지금 누른 기호가 나누기인 경우 (0으로 나눌 수 없음)
                        textView.setText(" ");
                        editText.setText("오류");
                        rule = "error";
                        break;
                    }
                    rule = "÷";
                    break;
                case R.id.multiply:
                    rule = "×";
                    break;
                case R.id.minus:
                    rule = "-";
                    break;
                case R.id.plus:
                    rule = "+";
                    break;
            }
        } else {    // 빈칸인 경우 메세지 출력
            //Toast.makeText(this, "숫자를 입력하세요.", Toast.LENGTH_SHORT).show();
        }
        if (check) { // 기호 연속 입력 시
            String tvtmp = textView.getText().toString();   // 뷰에 있는 문자열 받아옴
            tvtmp = tvtmp.substring(0, tvtmp.length() - 1);  // 문자열의 맨 끝자리(기호) 제거
            textView.setText(tvtmp + rule);                // 두번째 누른 기호 입력
        } else {      // 숫자 다음에 입력한 경우
            textView.append(rule);                         // 뷰에 기호 추가
        }
        check = true;           // 기호 입력 체크
    }//end

    public void equal(View v){                          // 등호의 경우
        String strtmp = editText.getText().toString();  // 입력 부분 문자열 받아옴
        if(!strtmp.equals("") && !check) {              // 입력 부분이 빈칸이 아니면서 직전에 기호를 입력하지 않은 경우
            float numtmp = Float.parseFloat(strtmp);    // 입력 부분 숫자로 전환
            if (!rule.equals("")) {                     // 기호가 입력 되었던 경우
                if (rule.equals("÷") && numtmp == 0) {  // 직전 기호가 나누기이고, 입력 부분이 0인 경우 오류
                    editText.setText("오류");
                    textView.setText(" ");
                    rule = "error";
                    return;
                }
                value2 = numtmp;                         // 두번째 값에 숫자를 넣음
                textView.append(setNum(numtmp) + "=");  // 뷰 부분에 추가
                calculate();     // 계산
                value1 = 0;     // 초기화
                rule = "=";     // 등호 입력 표시
                check=true;     // 기호 입력 표시
            }
        }
    }//end

    private void initialize(){      // 초기화 함수
        rule = "";
        textView.setText(" ");
        editText.setText("");
        value1 = 0;
        value2 = 0;
        check = false;
    }//end

    public void calculate(){   // 계산 함수
        switch (rule){
            case "÷":
                value1=value1/value2;
                break;
            case "×":
                value1=value1*value2;
                break;
            case "-":
                value1=value1-value2;
                break;
            case "+":
                value1=value1+value2;
                break;
        }
        editText.setText(setNum(value1));
        value2 = 0;                         // 계산 완료 시 두번째 값 초기화
    }//end

    public  String setNum(float num){   // 문자열이 소수점 아래 숫자가 있는 지 확인
        String print;
        if(Float.toString(num).endsWith(".0"))  // 소수점 아래 숫자가 없는 경우 ( 문자열이 .0 으로 끝나는 경우)
            print=String.valueOf((int)num);     // int 형으로 문자열 변환
        else                                    // 소수점 아래 숫자가 있는 경우
            print=String.valueOf(num);          // float형으로 문자열 변환
        return print;                           //문자열 리턴
    }//end

}//class END

